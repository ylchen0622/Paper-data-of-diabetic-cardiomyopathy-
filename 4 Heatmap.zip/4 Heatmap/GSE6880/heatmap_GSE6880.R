rm(list = ls())
setwd("./")
library(pheatmap)
library(Biobase)

# Load Difference Analysis Results of GSE6880
load("../../1 Difference analysis/GSE6880/.Rdata")

# Read the expressioon of common DEGs in GSE6880
ComDiffGene <- read.table("../../2 Common differentially expressed genes/ComDiffGene.txt", stringsAsFactors = F)
rownames(ComDiffGene) <- ComDiffGene[,1]
ComDiffGeneData = expr[which(rownames(expr) %in% rownames(ComDiffGene)),]
write.csv(ComDiffGeneData, file = "ComDiffUpGeneData.csv")

# Set Group
gsms <- paste0("000111")
sml  <- c()
for(i in 1:nchar(gsms)){
    sml[i] <- substr(gsms,i,i)
}
group = ifelse(sml == "0", "Ventricle Control","Ventricle Diabete")
annotation_col = data.frame(Sample = group)
rownames(annotation_col)  = colnames(ComDiffGeneData)

# Pheatmap Drawing
pdf(file = "GSE6880_Overlapping_heatmap.pdf",  width = 10, height = 10)
pheatmap(ComDiffGeneData,annotation_col = annotation_col,scale = "row",cluster_cols = F,
         show_rownames = T, color = colorRampPalette(c('blue','black','red'))(100),
         clustering_distance_cols = 'maximum',treeheight_col = 35, fontsize_row = 10 ,fontsize_col = 10,
         cluster_rows = T,show_colnames = T, cellwidth = 55, cellheight = 15, display_numbers = F,
         annotation_colors = list(Sample = c("Ventricle Control" = 'yellow', "Ventricle Diabete" = 'green')))
dev.off()
