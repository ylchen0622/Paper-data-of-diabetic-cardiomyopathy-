setwd("../GSE6880")
library(Biobase)
library(GEOquery)
library(ggplot2)
library(limma)
gset <- getGEO("GSE6880", GSEMatrix =TRUE, AnnotGPL=TRUE)  
Exprs <- exprs(gset[[1]])
Symbol.ID<-gset$GSE6880_series_matrix.txt.gz@featureData[[3]]
Origin_Gene_Expr_Values=cbind(Symbol.ID,Exprs)
write.csv(Origin_Gene_Expr_Values,file="Origin_Gene_Expr_Values.csv")
Exprs[Exprs<5]=5
range(Exprs)
LogExpr=log2(Exprs)

# Data Preprocssing
Symbol.ID<-gset$GSE6880_series_matrix.txt.gz@featureData[[3]]
Expr.Untreated=cbind(Symbol.ID,LogExpr)
write.csv(Expr.Untreated,file="Expr.Untreated.csv")
Expr.Untreated <-read.csv("Expr.Untreated.csv",header=TRUE,na.strings = "")
rownames(Expr.Untreated)<-Expr.Untreated[,1]
Expr.Untreated=Expr.Untreated[,-1]
ExprDelNaPro<-na.omit(Expr.Untreated)
ExprDelExtraGene<-ExprDelNaPro[!grepl(pattern = "///",ExprDelNaPro[,"Symbol.ID"]),]
expr=aggregate(ExprDelExtraGene[,c(2:(ncol(ExprDelExtraGene)))],by=list(ExprDelExtraGene$Symbol.ID),mean)
expr<-data.frame(expr)
rownames(expr)<-expr[,1]
expr<-expr[,-1]

# Build grouping matrix
group_list<-c(rep("Normal_heart",3),rep("Diabetic_heart",3))
design<-model.matrix(~0+factor(group_list))
colnames(design)=levels(factor(group_list))
rownames(design)=colnames(expr)
contrast.matrix<-makeContrasts(Diabetic_heart-Normal_heart,levels = design)

# Boxplot Drawing
expr=normalizeBetweenArrays(as.matrix(expr),method="quantile") 
par(mar=c(6+round(max(nchar(sampleNames(gset)))/2),5,3,2),cex=0.8)
palette(c("red","blue", "black"))
boxplot(expr,main="GSE6880 boxplot",col=as.factor(group_list),las=1,outline=F,notch=F,xlab="Sample",ylab="Expression Value")
legend("topright",cex=0.8,c("Control","Disease"),fill=c("blue","red"),bty='n')
dev.off()
write.csv(expr,file="expr.csv")

# Difference Analysis
fit<-lmFit(expr,design)  
fit2<-contrasts.fit(fit,contrast.matrix)
fit2<-eBayes(fit2)       
allDEGs=topTable(fit2,coef=1,adjust="fdr",number=200000)
allDEGs=na.omit(allDEGs)
write.csv(allDEGs,file="allDEGs.csv")

# Screening of the DEGs
SelectVector1 = (allDEGs$P.Value<0.05) & (abs(allDEGs$logFC) >= 1)
DEGs = allDEGs[SelectVector1,]
write.csv(DEGs,file="DEGs.csv")

# Screening of the Up-regulated DEGs
SelectVector2 = (allDEGs$P.Value<0.05) & (allDEGs$logFC >= 1)
DiffUpGene = allDEGs[SelectVector2,]
write.csv(DiffUpGene,file="DiffUpGene.csv")

# Screening of the Down-regulated DEGs
SelectVector3 = (allDEGs$P.Value<0.05) & (allDEGs$logFC<= -1)
DiffDownGene = allDEGs[SelectVector3,]
write.csv(DiffDownGene,file="DiffDownGene.csv")

