rm(list=ls())
setwd("../GSE4745")
allDEGs<-read.csv("../../1 Difference analysis/GSE4745/allDEGs.csv",stringsAsFactors = F)

# Volcano map drawing
plot(allDEGs$logFC,-log10(allDEGs$P.Value),pch=16,main="Volcano map(GSE4745)",cex.lab=1,
     xlab="log2(FoldChange)",ylab="-log10(P-value)",xlim=(c(-10,10)),ylim=(c(0,9)))
points(allDEGs[allDEGs$logFC>=1 & allDEGs$P.Value<0.05,]$logFC,pch=16,
       -log10(allDEGs[allDEGs$logFC>=1 & allDEGs$P.Value<0.05,]$P.Value),col='red')
points(allDEGs[allDEGs$logFC<=-1 & allDEGs$P.Value<0.05,]$logFC,pch=16,
       -log10(allDEGs[allDEGs$logFC<=-1 & allDEGs$P.Value<0.05,]$P.Value),col='blue')
legend("topright",legend = c("DiffUpGene","DiffDownGene"),col=c("red","blue"),xpd=TRUE,cex=0.6,pch=16,text.width =1.2)
interesting_genes=allDEGs[abs(allDEGs$logFC)>=3 & allDEGs$P.Value<0.05,]
write.csv(interesting_genes,file="interesting_genes.csv")
text(interesting_genes$logFC,-log10(interesting_genes$P.Value),
     interesting_genes$X,cex=0.6,pos=1,font=2)

