library(ggplot2)
library(stringr)
library(clusterProfiler)
library(org.Rn.eg.db)  

#��1�� GO Enrichment Analysis
GeneSymbolID<- read.table("DiffDownGene.txt", header = F, comment.char = "")
GeneSymbolID = as.character(GeneSymbolID[, 1])
GeneIdTrans <- bitr(GeneSymbolID, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = "org.Rn.eg.db")
GeneEntrezID <- as.character(GeneIdTrans[, 2])
go <- enrichGO(GeneEntrezID, OrgDb = "org.Rn.eg.db", ont = "all", pAdjustMethod="none")
barplot(go, split = "ONTOLOGY")+facet_grid(ONTOLOGY~., scale = "free")+labs(title = "EnrichmentGO_Down")+theme(plot.title = element_text(hjust = 0.5))

# ��2��KEGG Enrichment Analysis
kegg <- enrichKEGG(gene = GeneEntrezID, organism = 'rno', pAdjustMethod = "none")
KEGG <- setReadable(kegg, OrgDb = org.Rn.eg.db, keyType = "ENTREZID")
barplot(KEGG, showCategory = 15, beside = T)+labs(title = "EnrichmentKEGG_Down")+theme(plot.title = element_text(hjust = 0.5))
write.csv(KEGG, "KeggEnrichResult.csv", row.names = F)

